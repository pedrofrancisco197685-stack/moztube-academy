// TROCAR PÁGINAS

function trocarPagina(id){

  const paginas =
  document.querySelectorAll(".pagina");

  paginas.forEach(pagina => {

    pagina.classList.remove("ativa");

  });

  document
    .getElementById(id)
    .classList.add("ativa");
}

// RELÓGIO

const relogio =
document.getElementById("relogio");

const data =
document.getElementById("data");

function atualizar(){

  const agora = new Date();

  relogio.textContent =
  agora.toLocaleTimeString("pt-BR");

  data.textContent =
  agora.toLocaleDateString(
    "pt-BR",
    {
      weekday:"long",
      day:"numeric",
      month:"long",
      year:"numeric"
    }
  );
}

setInterval(atualizar,1000);

atualizar();